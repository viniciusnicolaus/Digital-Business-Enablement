package br.com.fiap.ws.dao;

import br.com.fiap.ws.entity.Noticia;

public interface NoticiaDAO extends GenericDAO<Noticia, Integer> {

	
}
